package com.example.user1.sqliteexample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button bt_insert,bt_retrive;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt_insert = (Button)findViewById(R.id.btinsert);
        bt_retrive = (Button)findViewById(R.id.btretrive);
        setInsert();
        setRetrive();
    }
    private void setInsert(){
        bt_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,InsertData.class);
                startActivity(intent);
            }
        });
    }
    private void setRetrive(){
        bt_retrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Retrive.class);
                startActivity(intent);
            }
        });
    }
}
