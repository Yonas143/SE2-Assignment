package com.example.user1.sqliteexample;

/**
 * Created by user1 on 6/8/2017.
 */
import android.content.ContentValues;
import android.content.Context;
import android.database.*;
import android.database.sqlite.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String db_name = "lab_demo";
    private static final String table_name = "user";
    private static final String col1 = "user_id";
    private static final String col2 = "fname";
    private static final String col3 = "lname";
    private static final String col4 = "phone";
    SQLiteDatabase database;
    ContentValues values;
    public DatabaseHelper(Context context){
        super(context,db_name,null,1);
        database = getWritableDatabase();
        values = new ContentValues();
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + table_name + "(" +
                "user_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "fname TEXT,lname TEXT,phone TEXT" +
                ")");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + table_name);
        onCreate(db);
    }
    public boolean register(String fname,String lname,String phone){
        boolean registered = false;
        values.put(col2,fname);
        values.put(col3,lname);
        values.put(col4,phone);
        long result = database.insert(table_name,null,values);
        if(result != -1){
            registered = true;
        }
        return registered;
    }
    public Cursor listRegisterd(){
        Cursor data = database.rawQuery("SELECT * from " + table_name,null);
        return data;
    }
    public Cursor detailData(String id){
        Cursor data = database.rawQuery("SELECT * from " + table_name
                + " WHERE user_id=?"
                ,new String[]{id});
        return data;
    }
}
