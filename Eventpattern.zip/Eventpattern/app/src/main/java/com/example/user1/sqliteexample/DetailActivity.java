package com.example.user1.sqliteexample;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    Intent intent;
    String fname,lname,phone;
    TextView tvFname,tvLname,tvPhone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        databaseHelper = new DatabaseHelper(DetailActivity.this);
        intent = getIntent();

        String index = intent.getStringExtra("id");

        Cursor data = databaseHelper.detailData(index);

        while (data.moveToNext()){
            fname = data.getString(1);
            lname = data.getString(2);
            phone = data.getString(3);
        }
        tvFname = (TextView)findViewById(R.id.tvfname);
        tvLname = (TextView)findViewById(R.id.tvlname);
        tvPhone = (TextView)findViewById(R.id.tvphone);

        tvFname.setText("First Name: "+ fname);
        tvLname.setText("Last Name: " + lname);
        tvPhone.setText("Phone: "+phone);
    }
}
