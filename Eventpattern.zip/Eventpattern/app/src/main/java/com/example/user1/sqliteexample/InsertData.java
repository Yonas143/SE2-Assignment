package com.example.user1.sqliteexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InsertData extends AppCompatActivity {
    EditText etFname,etLname,etPhone;
    Button btSave;
    DatabaseHelper databaseHelper;
    String fname,lname,phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_data);
        databaseHelper = new DatabaseHelper(this);

        etFname = (EditText)findViewById(R.id.etfname);
        etLname = (EditText)findViewById(R.id.etlname);
        etPhone = (EditText)findViewById(R.id.etphone);

        btSave = (Button)findViewById(R.id.btSave);
        setSave();
    }
    private void setSave(){
        btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fname = etFname.getText().toString();
                lname = etLname.getText().toString();
                phone = etPhone.getText().toString();
                boolean registered = databaseHelper.register(fname,lname,phone);
                if (registered){
                    Toast.makeText(InsertData.this,"registered",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
